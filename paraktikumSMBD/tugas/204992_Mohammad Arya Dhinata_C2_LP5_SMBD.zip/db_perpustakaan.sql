-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 19, 2026 at 05:37 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` varchar(10) NOT NULL,
  `judul_buku` varchar(200) NOT NULL,
  `pengarang` varchar(100) NOT NULL,
  `id_kategori` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `judul_buku`, `pengarang`, `id_kategori`) VALUES
('Bhmc', 'Bazura: Holy Magic Contradiction?', 'Mary Kasparov', 'MG'),
('ECfUMA', 'Experimental Charms for Unstable Magical Artifacts', 'Bridget Wenlock', 'SD'),
('IIaHMiWC', 'Invisible Ink and Hidden Messages in Wizard Communication', 'Ignatia Wildsmith', 'SD'),
('MHrpotsh', 'Magical Herbology: Rare Plants of the Scottish Highlands', 'Pomona Sprout', 'HA'),
('ODRfNC', 'Obscure Defensive Runes for Nocturnal Creatures', 'Cassandra Vablatsky', 'RK'),
('PSiUE', 'Potion Stabilization in Uncontrolled Environments', 'Arsenius Jigger', 'RM'),
('TAiMTD', 'Temporal Anomalies in Magical Timekeeping Devices', 'Saul Croaker', 'TL'),
('ToSsOV8', 'Transfiguration of Semi-Sentient Objects Vol. VII', 'Elphias Doge', 'SD'),
('WotFFafs', 'Whispers of the Forbidden Forest: A Field Study', 'Galatea Merrythought', 'MG');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` char(5) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
('HA', 'Herbologi & Alam'),
('MG', 'Makhluk Gaib'),
('RK', 'Rune & Kutukan'),
('RM', 'Ramuan'),
('SD', 'Sihir Dasar'),
('TL', 'Time & Magic Lanjutan');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_peminjaman` int NOT NULL,
  `id_buku` varchar(10) NOT NULL,
  `nama_peminjam` varchar(100) NOT NULL,
  `tgl_pinjam` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`id_peminjaman`, `id_buku`, `nama_peminjam`, `tgl_pinjam`) VALUES
(301, 'TAiMTD', 'Padma Patil', '2026-03-28'),
(302, 'ODRfNC', 'Blaise Zabini', '2026-03-30'),
(303, 'ToSsOV8', 'Terry Boot', '2026-04-01'),
(304, 'WotFFafs', 'Susan Bones', '2026-04-02'),
(305, 'PSiUE', 'Anthony Goldstein', '2026-04-03'),
(306, 'IIaHMiWC', 'Cho Chang', '2026-04-06'),
(307, 'MHrpotsh', 'Neville Longbottom', '2026-04-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_peminjaman`),
  ADD KEY `id_buku` (`id_buku`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id_peminjaman` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=311;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `buku_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`) ON DELETE RESTRICT ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
